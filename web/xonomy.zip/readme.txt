﻿Xonomy: a web-based, schema-driven XML editor.
Written by Michal Boleslav Měchura.
http://lexiconista.com/xonomy

This is version 2.4 of Xonomy, released 24 February 2016.

Xonomy can be used under the Creative Commons ‘Attribution 4.0 International’ licence:
http://creativecommons.org/licenses/by/4.0/
